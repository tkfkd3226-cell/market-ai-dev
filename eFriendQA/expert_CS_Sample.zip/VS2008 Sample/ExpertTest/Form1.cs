﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExpertTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // object가 tr 호출이 한번 일어나야 계좌를 정상적으로 가져올 수 있으므로, 초기화 시 호출
            axTR1.RequestData("FOCP");
            cmbBuySell.SelectedIndex = 0;
            cmbChe.SelectedIndex = 0;
        }
        // 계좌조회 버튼 클릭시 처리
        private void button1_Click(object sender, EventArgs e)
        {
            cmbAccount.Items.Clear();
            short i;
            for (i = 0; i < axTR1.GetAccountCount(); i++)
            {
                String Account = (String)axTR1.GetAccount(i);
                String sPdNo = Account.Substring(8);
                // 선물 계좌만 필터링 시켜 추가
                if (sPdNo == "03")
                {
                    cmbAccount.Items.Add(axTR1.GetAccount(i));
                }
                if (cmbAccount.Items.Count > 0)
                {
                    cmbAccount.SelectedIndex = 0;
                }
            }
        }
        // 주문체결내역조회 버튼 클릭
        private void button1_Click_1(object sender, EventArgs e)
        {
            axFOOAC.SetSingleData(0, cmbAccount.SelectedItem.ToString().Substring(0,8));  //종합계좌번호
            axFOOAC.SetSingleData(1, cmbAccount.SelectedItem.ToString().Substring(8, 2)); //상품계좌번호 ("03")
            axFOOAC.SetSingleData(2, axFOOAC.GetEncryptPassword(txtPassword.Text) );      //계좌비밀번호 (암호화 함수 처리하여 채움)
            axFOOAC.SetSingleData(3, dtpStart.Value.ToString("yyyyMMdd"));
            axFOOAC.SetSingleData(4, dtpEnd.Value.ToString("yyyyMMdd"));
            axFOOAC.SetSingleData(5, cmbBuySell.SelectedItem.ToString().Substring(0, 2)); //매수 매도 구분
            axFOOAC.SetSingleData(6, cmbChe.SelectedItem.ToString().Substring(0, 2));     //체결 미체결 구분
            String sSort = "DS"; // 역순
            if (!checkBox1.Checked)
            {
                // 정순
                sSort = "AS";
            }
            axFOOAC.SetSingleData(7, sSort); // 정렬 순서
            axFOOAC.SetSingleData(8, "");    // 시작주문번호
            axFOOAC.SetSingleData(9, "");    // 상품번호 (종목코드)
            axFOOAC.SetSingleData(10, "");   // 시장ID코드 (사용안함)
            axFOOAC.SetSingleData(11, "");   // 연속조회 검색조건 (1)
            axFOOAC.SetSingleData(12, "");   // 연속조회 검색조건 (2)
            axFOOAC.RequestData("FOOAC");    // 선물옵션 계좌별 주문 체결 내역 
        }
        // 주문 체결 내역조회 수신 처리 
        private void axFOOAC_ReceiveData(object sender, EventArgs e)
        {
            txtMemo.Text = "";
            txtMemo.AppendText("응답메시지: [" + axFOOAC.GetRtCode() + "] " + axFOOAC.GetReqMessage() + "\r\n");
            // index   4         5          6          7            8           9         10        11      13     14    15    16    17       18     19      20   21
            String OrderDate, OrderNo, OrgOrderNo, BuySellCode, BuySellName, HogaCode, HogaName, FuOpCode, FOCode, Qty, Price, LQty, OrdTime, TQty, APrice, TAmt, XQty;

            for (short i=0;i<axFOOAC.GetMultiRecordCount(0);i++)
            {
                String txtAppend = "";
                OrderDate   = (String)axFOOAC.GetMultiData(0, i, 4, 0); //주문일자
                txtAppend = txtAppend + ":" + OrderDate;
                OrdTime = (String)axFOOAC.GetMultiData(0, i, 17, 0);    //주문시간
                txtAppend = txtAppend + ":" + OrdTime;
                OrderNo = (String)axFOOAC.GetMultiData(0, i, 5, 0);     //주문번호
                txtAppend = txtAppend + ":" + OrderNo;
                OrgOrderNo  = (String)axFOOAC.GetMultiData(0, i, 6, 0); //원주문번호
                txtAppend = txtAppend + ":" + OrgOrderNo;
                BuySellCode = (String)axFOOAC.GetMultiData(0, i, 7, 0); //매수매도구분코드
                txtAppend = txtAppend + ":" + BuySellCode;
                BuySellName = (String)axFOOAC.GetMultiData(0, i, 8, 0); //매수매도구분명
                txtAppend = txtAppend + ":" + BuySellName;
                HogaCode    = (String)axFOOAC.GetMultiData(0, i, 9, 0); //호가유형코드
                txtAppend = txtAppend + ":" + HogaCode;
                HogaName    = (String)axFOOAC.GetMultiData(0, i, 10, 0);//호가유형명
                txtAppend = txtAppend + ":" + HogaName;
                FuOpCode    = (String)axFOOAC.GetMultiData(0, i, 11, 0);//종목코드
                txtAppend = txtAppend + ":" + FuOpCode;
                FOCode      = (String)axFOOAC.GetMultiData(0, i, 13, 0);//상풍유형코드
                txtAppend = txtAppend + ":" + FOCode;
                Qty         = (String)axFOOAC.GetMultiData(0, i, 14, 0);//주문수량
                txtAppend = txtAppend + ":" + Qty;
                Price       = (String)axFOOAC.GetMultiData(0, i, 15, 0);//주문가격
                txtAppend = txtAppend + ":" + Price;
                LQty        = (String)axFOOAC.GetMultiData(0, i, 16, 0);//잔량
                txtAppend = txtAppend + ":" + LQty;
                TQty        = (String)axFOOAC.GetMultiData(0, i, 18, 0);//총체결수량
                txtAppend = txtAppend + ":" + TQty;
                APrice      = (String)axFOOAC.GetMultiData(0, i, 19, 0);//평균가격
                txtAppend = txtAppend + ":" + APrice;
                TAmt        = (String)axFOOAC.GetMultiData(0, i, 20, 0);//총체결수량
                txtAppend = txtAppend + ":" + TAmt;
                XQty        = (String)axFOOAC.GetMultiData(0, i, 21, 0);//거부수량
                txtAppend = txtAppend + ":" + XQty;
                txtMemo.AppendText(txtAppend + "\r\n");
            }
        }

        private void axFOOAC_ReceiveErrorData(object sender, EventArgs e)
        {
            txtMemo.AppendText("Error Messagesssss\r\n");
        }
        // 다음조회 처리
        private void button2_Click(object sender, EventArgs e)
        {
            axFOOAC.RequestNextData("FOOAC"); // 선물옵션 계좌별 주문 체결 내역   

        }
        // 주문버튼 클릭시 처리
        private void btnOrder_Click(object sender, EventArgs e)  
        {
            String strAcnt, strProd, strPass;
            String strTrgc;
            String strItem, strQty, strPrice;
            String strDvcd, strOptDv;

            if (rbBuy.Checked)
                strTrgc = "02"; // 매수
            else if (rbSell.Checked)
                strTrgc = "01"; // 매도
            else
            {
                return; // 주문안됨
            }

            int nCond = cbOrdCond.SelectedIndex;

            if (nCond < 0)
                return; // 주문구분 선택 안함


            switch (nCond)
            {
                case 0: strDvcd = "01"; strOptDv = "0"; break;  // 지정가, NONE
                case 1: strDvcd = "02"; strOptDv = "0"; break;  // 시장가, NONE
                case 2: strDvcd = "03"; strOptDv = "0"; break;  // 조건부, NONE
                case 3: strDvcd = "04"; strOptDv = "0"; break;  // 최유리, NONE
                case 4: strDvcd = "01"; strOptDv = "3"; break;  // 지정가, IOC
                case 5: strDvcd = "02"; strOptDv = "3"; break;  // 시장가, IOC
                case 6: strDvcd = "04"; strOptDv = "3"; break;  // 최유리, IOC
                case 7: strDvcd = "01"; strOptDv = "4"; break;  // 지정가, FOK
                case 8: strDvcd = "02"; strOptDv = "4"; break;  // 시장가, FOK 
                case 9: strDvcd = "04"; strOptDv = "4"; break;  // 최유리, FOK
                default: strDvcd = ""; strOptDv = "";   break;
            }

            if (strDvcd == "" || strOptDv == "")
                return;

            strItem = txtItemCode.Text;
            strQty = txtQty.Text;
            strPrice = txtPrice.Text;

            if (strDvcd == "02" || strDvcd == "04")
                strPrice = "0"; // 시장가 또는 최유리는 가격을 0으로 셋팅

            strAcnt = cmbAccount.SelectedItem.ToString().Substring(0, 8);      //종합계좌번호
            strProd = cmbAccount.SelectedItem.ToString().Substring(8, 2);      //상품계좌번호 ("03") 
            strPass = axFOOrd.GetEncryptPassword(txtPassword.Text).ToString(); //계좌비밀번호 (암호화 함수 처리하여 채움)

            axFOOrd.SetSingleData(0, "02");    //주문처리구분
            axFOOrd.SetSingleData(1, strAcnt); //종합계좌번호
            axFOOrd.SetSingleData(2, strProd); //상품계좌번호 ("03")
            axFOOrd.SetSingleData(3, strPass); //계좌비밀번호 (암호화 함수 처리하여 채움)
            axFOOrd.SetSingleData(4, strTrgc); // 매매거래구분코드(01:매도, 02:매수)
            axFOOrd.SetSingleData(5, strItem); // 종목
            axFOOrd.SetSingleData(6, strQty);  // 수량
            axFOOrd.SetSingleData(7, strPrice);// 가격
            axFOOrd.SetSingleData(8, strDvcd); // 집행구분 => 호가유형 
            axFOOrd.SetSingleData(9, strOptDv);// 주문조건 => IOC/FOK => 0: 없음, 3: IOC, 4: FOK

            // 과거에는 선물옵션 매수 매도가 분리되어 있었으나,
            // 현재는 FOB, FOA, OOB, OOA 다 동일하게 동작함
            if (rbBuy.Checked)
                axFOOrd.RequestData("FOB");   //선물 매수 주문 처리
            else
                axFOOrd.RequestData("FOA");   //선물 매도 주문 처리
        }

        // 주문 체결 처리 내역 수신처리 
        private void axFOOrd_ReceiveData(object sender, EventArgs e)
        {
            // 0 : 계좌명
            // 1 : 매매구분명
            // 2 : 종목명
            // 3 : 주문시각
            // 4 : 지점번호
            // 5 : 주문번호 (원주문번호:정정,취소)
            // 6 : 주문번호
            txtMemo.AppendText("응답메시지: [" + axFOOrd.GetRtCode() + "] " + axFOOrd.GetReqMessage() + "\r\n");

            String txtAppend = "";

            txtAppend = txtAppend + (String)axFOOrd.GetSingleData(0, 0);
            txtAppend = txtAppend + ":" + (String)axFOOrd.GetSingleData(1, 0);
            txtAppend = txtAppend + ":" + (String)axFOOrd.GetSingleData(2, 0);
            txtAppend = txtAppend + ":" + (String)axFOOrd.GetSingleData(3, 0);
            txtAppend = txtAppend + ":" + (String)axFOOrd.GetSingleData(4, 0);
            txtAppend = txtAppend + ":" + (String)axFOOrd.GetSingleData(5, 0);
            txtAppend = txtAppend + ":" + (String)axFOOrd.GetSingleData(6, 0);
            txtMemo.AppendText(txtAppend + "\r\n");
        }

        // 정정/취소 주문 처리 
        private void btnModCancel_Click(object sender, EventArgs e)
        {
            String strAcnt, strProd, strPass;
            String strTrgc;
            String strItem, strQty, strPrice;
            String strDvcd, strOptDv;
            String strNetQty, strOrgNo;

            strItem = txtItemCode.Text;
            strQty = txtQty.Text;
            strPrice = txtPrice.Text;
            strOrgNo = txtOrderNo.Text;

            if (rbModify.Checked)
                strTrgc = "01"; // 정정
            else if (rbCancel.Checked)
            {
                strTrgc = "02"; // 취소
                strQty = "0";
                strPrice = "0";
            }
            else
            {
                return; // 주문안됨
            }

            int nCond = cbOrdCond.SelectedIndex;

            if (nCond < 0)
                return; // 주문구분 선택 안함


            switch (nCond)
            {
                case 0: strDvcd = "01"; strOptDv = "0"; break;  // 지정가, NONE
                case 1: strDvcd = "02"; strOptDv = "0"; break;  // 시장가, NONE
                case 2: strDvcd = "03"; strOptDv = "0"; break;  // 조건부, NONE
                case 3: strDvcd = "04"; strOptDv = "0"; break;  // 최유리, NONE
                case 4: strDvcd = "01"; strOptDv = "3"; break;  // 지정가, IOC
                case 5: strDvcd = "02"; strOptDv = "3"; break;  // 시장가, IOC
                case 6: strDvcd = "04"; strOptDv = "3"; break;  // 최유리, IOC
                case 7: strDvcd = "01"; strOptDv = "4"; break;  // 지정가, FOK
                case 8: strDvcd = "02"; strOptDv = "4"; break;  // 시장가, FOK 
                case 9: strDvcd = "04"; strOptDv = "4"; break;  // 최유리, FOK
                default: strDvcd = ""; strOptDv = ""; break;
            }

            if (strDvcd == "" || strOptDv == "")
                return;

            if (strDvcd == "02" || strDvcd == "04")
                strPrice = "0"; // 시장가 또는 최유리는 가격을 0으로 셋팅

            nCond = cbJanCond.SelectedIndex;

            if (nCond == 0)
                strNetQty = "N";    // 일부정정
            else
                strNetQty = "Y";

            strAcnt = cmbAccount.SelectedItem.ToString().Substring(0, 8);      //종합계좌번호
            strProd = cmbAccount.SelectedItem.ToString().Substring(8, 2);      //상품계좌번호 ("03")
            strPass = axFOOrd.GetEncryptPassword(txtPassword.Text).ToString(); //계좌비밀번호 (암호화 함수 처리하여 채움)

            axFOOrd.SetSingleData(0, "02");      //주문처리구분
            axFOOrd.SetSingleData(1, strAcnt);   //종합계좌번호
            axFOOrd.SetSingleData(2, strProd);   //상품계좌번호 ("03")
            axFOOrd.SetSingleData(3, strPass);   //계좌비밀번호 (암호화 함수 처리하여 채움)
            axFOOrd.SetSingleData(4, strTrgc);   // 정정/취소 구분

            axFOOrd.SetSingleData(5, strOrgNo);  // 원주문번호
            axFOOrd.SetSingleData(6, strQty);	 // 수량
            axFOOrd.SetSingleData(7, strPrice);	 // 가격
            axFOOrd.SetSingleData(8, strDvcd);	 // 집행구분 => 호가유형 
            axFOOrd.SetSingleData(9, strOptDv);	 // 주문조건 => IOC/FOK => 0: 없음, 3: IOC, 4: FOK
            axFOOrd.SetSingleData(10, strNetQty);// 잔량구분
            axFOOrd.SetSingleData(11, "");	     // 전화번호
            axFOOrd.SetSingleData(12, "02");	 // 전화번호
            axFOOrd.SetSingleData(13, strDvcd);	 // 집행구분 => 호가유형 

            axFOOrd.RequestData("FOOMC");   // 정정, 취소
        }

        // 잔고조회 버튼 클릭 처리
        private void button3_Click(object sender, EventArgs e)
        {
            axFOOQP.SetSingleData(0, cmbAccount.SelectedItem.ToString().Substring(0, 8)); //종합계좌번호
            axFOOQP.SetSingleData(1, cmbAccount.SelectedItem.ToString().Substring(8, 2)); //상품계좌번호 ("03")
            axFOOQP.SetSingleData(2, axFOOQP.GetEncryptPassword(txtPassword.Text));       //계좌비밀번호 (암호화 함수 처리하여 채움)
            axFOOQP.SetSingleData(3, "01"); // "01:개시 02:유지
            axFOOQP.SetSingleData(4, "1");  // "1:정산 2:본정산"
            axFOOQP.RequestData("FOOQP");   // 잔고조회
        }

        // 잔고조회 수신처리 
        private void axFOOQP_ReceiveData(object sender, EventArgs e)
        {
            String[] strTitle = {
                "단축상품번호","상품명", "매도/매수", "잔고수량", "정산단가",
                "체결평균단가","지수종가","매입금액","평가금액","평가손익금액","매매손익금액","청산가능수량"};
            int nRecCount = axFOOQP.GetMultiRecordCount(0);
            int nFieldCount;
            String strValue;
            String sTitle;
            txtMemo.AppendText("응답메시지: [" + axFOOQP.GetRtCode() + "] " + axFOOQP.GetReqMessage() + "\r\n");
            for (short i = 0; i < nRecCount; i++)
            {
                nFieldCount = axFOOQP.GetMultiFieldCount(0, i);
                String txtAppend = "";
                for (short j = 4; j < nFieldCount; j++)
                {
                    if (strTitle.GetUpperBound(0) <= j-4)
                    {
                        sTitle = strTitle[j-4];
                    }
                    else
                    {
                        sTitle = "";
                    }
                    strValue = "[" + strTitle[j-4] + ":" + (String)axFOOQP.GetMultiData(0, i, j, 0) + "]";
                    txtAppend = txtAppend + strValue;
                }

                txtMemo.AppendText(txtAppend + "\r\n");
            }

        }
    }
}
