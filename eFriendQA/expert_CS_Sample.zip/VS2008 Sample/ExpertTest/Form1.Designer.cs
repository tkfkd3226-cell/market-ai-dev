﻿namespace ExpertTest
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.cmbAccount = new System.Windows.Forms.ComboBox();
            this.axTR1 = new AxITGExpertCtlLib.AxITGExpertCtl();
            this.label1 = new System.Windows.Forms.Label();
            this.btnQueryAccount = new System.Windows.Forms.Button();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.axFOOAC = new AxITGExpertCtlLib.AxITGExpertCtl();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.cmbChe = new System.Windows.Forms.ComboBox();
            this.cmbBuySell = new System.Windows.Forms.ComboBox();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.txtMemo = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.axFOJL = new AxITGExpertCtlLib.AxITGExpertCtl();
            this.label4 = new System.Windows.Forms.Label();
            this.rbBuy = new System.Windows.Forms.RadioButton();
            this.rbSell = new System.Windows.Forms.RadioButton();
            this.rbModify = new System.Windows.Forms.RadioButton();
            this.rbCancel = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.txtOrderNo = new System.Windows.Forms.TextBox();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cbOrdCond = new System.Windows.Forms.ComboBox();
            this.cbJanCond = new System.Windows.Forms.ComboBox();
            this.btnOrder = new System.Windows.Forms.Button();
            this.btnModCancel = new System.Windows.Forms.Button();
            this.axFOOrd = new AxITGExpertCtlLib.AxITGExpertCtl();
            this.txtItemCode = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.axFOOQP = new AxITGExpertCtlLib.AxITGExpertCtl();
            ((System.ComponentModel.ISupportInitialize)(this.axTR1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFOOAC)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axFOJL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFOOrd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFOOQP)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbAccount
            // 
            this.cmbAccount.FormattingEnabled = true;
            this.cmbAccount.Location = new System.Drawing.Point(85, 12);
            this.cmbAccount.Name = "cmbAccount";
            this.cmbAccount.Size = new System.Drawing.Size(145, 20);
            this.cmbAccount.TabIndex = 0;
            // 
            // axTR1
            // 
            this.axTR1.Enabled = true;
            this.axTR1.Location = new System.Drawing.Point(596, 10);
            this.axTR1.Name = "axTR1";
            this.axTR1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axTR1.OcxState")));
            this.axTR1.Size = new System.Drawing.Size(28, 29);
            this.axTR1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "계좌번호";
            // 
            // btnQueryAccount
            // 
            this.btnQueryAccount.Location = new System.Drawing.Point(396, 10);
            this.btnQueryAccount.Name = "btnQueryAccount";
            this.btnQueryAccount.Size = new System.Drawing.Size(75, 21);
            this.btnQueryAccount.TabIndex = 3;
            this.btnQueryAccount.Text = "계좌조회";
            this.btnQueryAccount.UseVisualStyleBackColor = true;
            this.btnQueryAccount.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(306, 11);
            this.txtPassword.MaxLength = 8;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(75, 21);
            this.txtPassword.TabIndex = 4;
            this.txtPassword.WordWrap = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(247, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "비밀번호";
            // 
            // axFOOAC
            // 
            this.axFOOAC.Enabled = true;
            this.axFOOAC.Location = new System.Drawing.Point(641, 10);
            this.axFOOAC.Name = "axFOOAC";
            this.axFOOAC.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axFOOAC.OcxState")));
            this.axFOOAC.Size = new System.Drawing.Size(28, 29);
            this.axFOOAC.TabIndex = 6;
            this.axFOOAC.ReceiveData += new System.EventHandler(this.axFOOAC_ReceiveData);
            this.axFOOAC.ReceiveErrorData += new System.EventHandler(this.axFOOAC_ReceiveErrorData);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 251);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(773, 352);
            this.tabControl1.TabIndex = 16;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.checkBox1);
            this.tabPage1.Controls.Add(this.cmbChe);
            this.tabPage1.Controls.Add(this.cmbBuySell);
            this.tabPage1.Controls.Add(this.dtpEnd);
            this.tabPage1.Controls.Add(this.dtpStart);
            this.tabPage1.Controls.Add(this.txtMemo);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(765, 326);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "주문체결내역조회";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(548, 22);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(116, 23);
            this.button3.TabIndex = 25;
            this.button3.Text = "잔고조회";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(670, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(82, 19);
            this.button2.TabIndex = 24;
            this.button2.Text = "다음조회";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(548, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(116, 19);
            this.button1.TabIndex = 23;
            this.button1.Text = "주문체결내역조회";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 22;
            this.label3.Text = "시작일자";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(484, 5);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(48, 16);
            this.checkBox1.TabIndex = 21;
            this.checkBox1.Text = "역순";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // cmbChe
            // 
            this.cmbChe.FormattingEnabled = true;
            this.cmbChe.Items.AddRange(new object[] {
            "00 전체",
            "01 체결",
            "02 미체결"});
            this.cmbChe.Location = new System.Drawing.Point(386, 2);
            this.cmbChe.Name = "cmbChe";
            this.cmbChe.Size = new System.Drawing.Size(76, 20);
            this.cmbChe.TabIndex = 20;
            // 
            // cmbBuySell
            // 
            this.cmbBuySell.FormattingEnabled = true;
            this.cmbBuySell.Items.AddRange(new object[] {
            "00 전체",
            "01 매도",
            "02 매수"});
            this.cmbBuySell.Location = new System.Drawing.Point(295, 1);
            this.cmbBuySell.Name = "cmbBuySell";
            this.cmbBuySell.Size = new System.Drawing.Size(76, 20);
            this.cmbBuySell.TabIndex = 19;
            // 
            // dtpEnd
            // 
            this.dtpEnd.CustomFormat = "YYYY-MM-DD";
            this.dtpEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEnd.Location = new System.Drawing.Point(182, 1);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(89, 21);
            this.dtpEnd.TabIndex = 18;
            // 
            // dtpStart
            // 
            this.dtpStart.CustomFormat = "YYYY-MM-DD";
            this.dtpStart.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpStart.Location = new System.Drawing.Point(59, 1);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(92, 21);
            this.dtpStart.TabIndex = 17;
            // 
            // txtMemo
            // 
            this.txtMemo.Font = new System.Drawing.Font("굴림체", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtMemo.Location = new System.Drawing.Point(0, 47);
            this.txtMemo.Multiline = true;
            this.txtMemo.Name = "txtMemo";
            this.txtMemo.Size = new System.Drawing.Size(762, 486);
            this.txtMemo.TabIndex = 16;
            this.txtMemo.WordWrap = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(765, 326);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "예수금 잔고";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // axFOJL
            // 
            this.axFOJL.Enabled = true;
            this.axFOJL.Location = new System.Drawing.Point(684, 10);
            this.axFOJL.Name = "axFOJL";
            this.axFOJL.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axFOJL.OcxState")));
            this.axFOJL.Size = new System.Drawing.Size(28, 29);
            this.axFOJL.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 18;
            this.label4.Text = "수량";
            // 
            // rbBuy
            // 
            this.rbBuy.AutoSize = true;
            this.rbBuy.Location = new System.Drawing.Point(90, 78);
            this.rbBuy.Name = "rbBuy";
            this.rbBuy.Size = new System.Drawing.Size(47, 16);
            this.rbBuy.TabIndex = 19;
            this.rbBuy.TabStop = true;
            this.rbBuy.Text = "매수";
            this.rbBuy.UseVisualStyleBackColor = true;
            // 
            // rbSell
            // 
            this.rbSell.AutoSize = true;
            this.rbSell.Location = new System.Drawing.Point(143, 78);
            this.rbSell.Name = "rbSell";
            this.rbSell.Size = new System.Drawing.Size(47, 16);
            this.rbSell.TabIndex = 19;
            this.rbSell.TabStop = true;
            this.rbSell.Text = "매도";
            this.rbSell.UseVisualStyleBackColor = true;
            // 
            // rbModify
            // 
            this.rbModify.AutoSize = true;
            this.rbModify.Location = new System.Drawing.Point(249, 78);
            this.rbModify.Name = "rbModify";
            this.rbModify.Size = new System.Drawing.Size(47, 16);
            this.rbModify.TabIndex = 19;
            this.rbModify.TabStop = true;
            this.rbModify.Text = "정정";
            this.rbModify.UseVisualStyleBackColor = true;
            // 
            // rbCancel
            // 
            this.rbCancel.AutoSize = true;
            this.rbCancel.Location = new System.Drawing.Point(302, 78);
            this.rbCancel.Name = "rbCancel";
            this.rbCancel.Size = new System.Drawing.Size(47, 16);
            this.rbCancel.TabIndex = 19;
            this.rbCancel.TabStop = true;
            this.rbCancel.Text = "취소";
            this.rbCancel.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(247, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 18;
            this.label6.Text = "원주문번호";
            // 
            // txtOrderNo
            // 
            this.txtOrderNo.Location = new System.Drawing.Point(318, 43);
            this.txtOrderNo.Name = "txtOrderNo";
            this.txtOrderNo.Size = new System.Drawing.Size(100, 21);
            this.txtOrderNo.TabIndex = 21;
            this.txtOrderNo.WordWrap = false;
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(85, 154);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(100, 21);
            this.txtQty.TabIndex = 22;
            this.txtQty.WordWrap = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(247, 157);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 23;
            this.label7.Text = "가격";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(306, 154);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(100, 21);
            this.txtPrice.TabIndex = 22;
            this.txtPrice.WordWrap = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 80);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 18;
            this.label8.Text = "매매거래";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 111);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 24);
            this.label9.TabIndex = 24;
            this.label9.Text = "집행구분\r\n주문조건";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(247, 114);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 24;
            this.label10.Text = "잔량구분";
            // 
            // cbOrdCond
            // 
            this.cbOrdCond.FormattingEnabled = true;
            this.cbOrdCond.Items.AddRange(new object[] {
            "지정가",
            "시장가",
            "조건부지정가",
            "최유리지정가",
            "지정가IOC",
            "시장가IOC",
            "최유리IOC",
            "지정가FOK",
            "시장가FOK",
            "최유리FOK"});
            this.cbOrdCond.Location = new System.Drawing.Point(85, 111);
            this.cbOrdCond.Name = "cbOrdCond";
            this.cbOrdCond.Size = new System.Drawing.Size(121, 20);
            this.cbOrdCond.TabIndex = 25;
            // 
            // cbJanCond
            // 
            this.cbJanCond.FormattingEnabled = true;
            this.cbJanCond.Items.AddRange(new object[] {
            "일부",
            "잔량전부"});
            this.cbJanCond.Location = new System.Drawing.Point(306, 111);
            this.cbJanCond.Name = "cbJanCond";
            this.cbJanCond.Size = new System.Drawing.Size(121, 20);
            this.cbJanCond.TabIndex = 26;
            // 
            // btnOrder
            // 
            this.btnOrder.Location = new System.Drawing.Point(16, 190);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(214, 55);
            this.btnOrder.TabIndex = 27;
            this.btnOrder.Text = "주문";
            this.btnOrder.UseVisualStyleBackColor = true;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // btnModCancel
            // 
            this.btnModCancel.Location = new System.Drawing.Point(249, 190);
            this.btnModCancel.Name = "btnModCancel";
            this.btnModCancel.Size = new System.Drawing.Size(214, 55);
            this.btnModCancel.TabIndex = 27;
            this.btnModCancel.Text = "정정/취소";
            this.btnModCancel.UseVisualStyleBackColor = true;
            this.btnModCancel.Click += new System.EventHandler(this.btnModCancel_Click);
            // 
            // axFOOrd
            // 
            this.axFOOrd.Enabled = true;
            this.axFOOrd.Location = new System.Drawing.Point(596, 45);
            this.axFOOrd.Name = "axFOOrd";
            this.axFOOrd.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axFOOrd.OcxState")));
            this.axFOOrd.Size = new System.Drawing.Size(28, 29);
            this.axFOOrd.TabIndex = 28;
            this.axFOOrd.ReceiveData += new System.EventHandler(this.axFOOrd_ReceiveData);
            // 
            // txtItemCode
            // 
            this.txtItemCode.Location = new System.Drawing.Point(85, 43);
            this.txtItemCode.Name = "txtItemCode";
            this.txtItemCode.Size = new System.Drawing.Size(100, 21);
            this.txtItemCode.TabIndex = 29;
            this.txtItemCode.Text = "101K12";
            this.txtItemCode.WordWrap = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 18;
            this.label5.Text = "종목코드";
            // 
            // axFOOQP
            // 
            this.axFOOQP.Enabled = true;
            this.axFOOQP.Location = new System.Drawing.Point(641, 46);
            this.axFOOQP.Name = "axFOOQP";
            this.axFOOQP.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axFOOQP.OcxState")));
            this.axFOOQP.Size = new System.Drawing.Size(28, 29);
            this.axFOOQP.TabIndex = 30;
            this.axFOOQP.ReceiveData += new System.EventHandler(this.axFOOQP_ReceiveData);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 610);
            this.Controls.Add(this.axFOOQP);
            this.Controls.Add(this.txtItemCode);
            this.Controls.Add(this.axFOOrd);
            this.Controls.Add(this.btnModCancel);
            this.Controls.Add(this.btnOrder);
            this.Controls.Add(this.cbJanCond);
            this.Controls.Add(this.cbOrdCond);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.txtOrderNo);
            this.Controls.Add(this.rbCancel);
            this.Controls.Add(this.rbModify);
            this.Controls.Add(this.rbSell);
            this.Controls.Add(this.rbBuy);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.axFOJL);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.axFOOAC);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.btnQueryAccount);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.axTR1);
            this.Controls.Add(this.cmbAccount);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.axTR1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFOOAC)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axFOJL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFOOrd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFOOQP)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbAccount;
        private AxITGExpertCtlLib.AxITGExpertCtl axTR1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnQueryAccount;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label2;
        private AxITGExpertCtlLib.AxITGExpertCtl axFOOAC;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ComboBox cmbChe;
        private System.Windows.Forms.ComboBox cmbBuySell;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.TextBox txtMemo;
        private System.Windows.Forms.TabPage tabPage2;
        private AxITGExpertCtlLib.AxITGExpertCtl axFOJL;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rbBuy;
        private System.Windows.Forms.RadioButton rbSell;
        private System.Windows.Forms.RadioButton rbModify;
        private System.Windows.Forms.RadioButton rbCancel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtOrderNo;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbOrdCond;
        private System.Windows.Forms.ComboBox cbJanCond;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.Button btnModCancel;
        private AxITGExpertCtlLib.AxITGExpertCtl axFOOrd;
        private System.Windows.Forms.TextBox txtItemCode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button3;
        private AxITGExpertCtlLib.AxITGExpertCtl axFOOQP;
    }
}

